Canary Curry / TofuCTF
======================

Requirements: Docker, netcat

1. Start the challenge service:
     chmod +x run.sh
     ./run.sh

2. Analyze the included `canary-curry` amd64 binary.

3. Connect locally:
     nc 127.0.0.1 31337

4. Retrieve the flag and submit it on TofuCTF.

5. Stop the service:
     ./run.sh stop

The service listens on localhost only. run.sh does not contact an external
service. The flag is derived locally and stored in a Docker volume; its literal
value is not present in run.sh or the extracted challenge directory.
